# Preparação da demonstração pública

Esta distribuição foi construída numa pasta nova, por seleção explícita de ficheiros. O histórico do projeto de trabalho não foi copiado.

- Os dados iniciais, empresas, contactos e cenários foram escritos para demonstração e são fictícios.
- O armazenamento do navegador utiliza um namespace exclusivo. Não importa o armazenamento de outra aplicação.
- Não inclui ficheiros de ambiente, credenciais, dados de prospeção, exportações, documentação interna, fotografias fornecidas ou integrações externas.
- O formulário apenas apresenta uma confirmação local; não envia dados. Os anúncios são conceitos demonstrativos.
- A fonte incluída conserva a licença original de terceiros.
- Os commits locais usam uma identidade de demonstração. O código foi submetido a uma revisão independente de privacidade antes da publicação.

O build estático foi verificado para as três rotas: painel, landing e anúncios. Esta cópia é um protótipo de apresentação, sem backend ou autenticação. Dados importados pelo visitante ficam apenas no respetivo navegador. Não introduza informações pessoais ou confidenciais.
