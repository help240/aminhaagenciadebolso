import localFont from 'next/font/local';
import './globals.css';
const font=localFont({src:'../public/fonts/Montserrat-Variable.ttf',weight:'400 700',display:'swap'});
export const metadata={title:'Agência de Bolso — Demonstração pública',description:'Protótipo demonstrativo com dados inteiramente fictícios. Sem envio de dados ou integrações externas.'};
export default function Layout({children}){return <html lang="pt"><body className={font.className}>{children}</body></html>}
