export default {devIndicators:false,output:'export',images:{unoptimized:true}};
