# Agência de Bolso — demonstração pública

Protótipo independente com dados inteiramente fictícios. Inclui painel de gestão editável, Canvas, calculadora de cenário, funil, CRM de exemplo, versões locais, landing e três criativos demonstrativos.

## Executar

Requer Node.js 20 ou superior e pnpm.

```sh
pnpm install
pnpm dev
```

Abra `http://127.0.0.1:3000`. Rotas: `/` (painel), `/agencia-de-bolso` (landing), `/anuncios` (criativos).

```sh
pnpm build
```

O build produz uma exportação estática em `out/`, adequada a alojamento estático. Não há API, configuração de ambiente, credenciais, integração Google, envio de formulário ou serviços externos.

## Dados e limites

Todos os dados iniciais foram escritos especificamente para esta demonstração. Não há empresas, contactos, estudos, documentos internos, metas operacionais ou fotografias de pessoas reais. Os links de contacto apontam apenas para `example.com`. Os anúncios são composições originais HTML/CSS, sem campanha ativa ou resultados alegados.

O painel guarda alterações apenas no localStorage do navegador sob a chave `agenciabolso-public-demo-v1`. É possível exportar/importar JSON, guardar até 15 versões e repor os dados iniciais. Não introduza dados pessoais, confidenciais ou reais nesta demonstração pública. A validação de importação é básica; este protótipo não é um serviço multiutilizador nem um sistema pronto para produção.

O formulário da landing apenas mostra uma confirmação local e limpa os campos. Nada é enviado ou guardado. A seleção regional da landing é apenas um controlo visual de demonstração, sem deteção por IP.

Os valores financeiros e percentuais do funil são cenários didáticos, não pesquisa de mercado nem previsão de receita. Não existe checkout, assinatura ou oferta comercial nesta cópia.

## Fonte

Montserrat é distribuída sob a SIL Open Font License. Consulte `public/fonts/Montserrat-OFL.txt`.
